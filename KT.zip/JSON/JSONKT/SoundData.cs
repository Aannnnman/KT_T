[System.Serializable]
public class SoundData
{
    public float Volume;

    public SoundData(float volume)
    {
        Volume = volume;
    }
}
