[System.Serializable]
public class DataBase
{
    public Data[] Data;

    public DataBase(Data[] data)
    {
        Data = data;
    }
}